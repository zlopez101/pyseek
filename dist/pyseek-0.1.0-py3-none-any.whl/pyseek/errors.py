class CIKNumberError(Exception):
    """Error when sending a non-existent CIK error"""

    pass
